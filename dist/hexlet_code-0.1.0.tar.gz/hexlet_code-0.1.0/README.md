### Hexlet tests and linter status:
[![Actions Status](https://github.com/byruleyolo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/byruleyolo/python-project-49/actions)
###CodeClimate:
[(https://codeclimate.com/github/byruleyolo/python-project-49/maintainability)](https://api.codeclimate.com/v1/badges/3d2f4a9264964d196601/maintainability)
###asciinema for brain-even
(https://asciinema.org/a/j73PcKfKfBu1M2Vs8U8EXaGDP)
### asciinema for brain-calc
(https://asciinema.org/a/iyHkAXtjK8F4sSTohgNwCSYVp

