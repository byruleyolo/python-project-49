### Hexlet tests and linter status:
[![Actions Status](https://github.com/byruleyolo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/byruleyolo/python-project-49/actions)
###CodeClimate:
[![mojno picat' 4to ygodno?](https://codeclimate.com/github/byruleyolo/python-project-49/maintainability)](https://api.codeclimate.com/v1/badges/3d2f4a9264964d196601/maintainability)
