### Hexlet tests and linter status:
[![Actions Status](https://github.com/byruleyolo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/byruleyolo/python-project-49/actions)
### CodeClimate:
[![Actions Status](https://codeclimate.com/github/byruleyolo/python-project-49/maintainability)](https://api.codeclimate.com/v1/badges/3d2f4a9264964d196601/maintainability)
### Asciinema for brain-even:
(https://asciinema.org/a/j73PcKfKfBu1M2Vs8U8EXaGDP)
### Asciinema for brain-calc:
(https://asciinema.org/a/iyHkAXtjK8F4sSTohgNwCSYVp)
### Asciinema for brain-gcd:
(https://asciinema.org/a/6nC5wxrbXQ90vV6ubgMQBETkb)
### Asciinema for brain-progression:
(https://asciinema.org/a/Y0FPeCdCOrE0UU72jKmIeHdD4)
### Asciinema for brain-prime:
( https://asciinema.org/a/FaiZRwSfl4SuMjhnl96JcqH3f)

